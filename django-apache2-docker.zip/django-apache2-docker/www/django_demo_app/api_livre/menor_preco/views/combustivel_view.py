from django.http import HttpResponse
from ..services import combustivel_services


def combustivel_list(request, lat, long, distancia, grupo, dias):
    items = combustivel_services.listar_combustivel(latitude=lat, longitude=long, distancia=distancia, grupo=grupo, dias=dias)
    return HttpResponse(items, content_type='application/json')
