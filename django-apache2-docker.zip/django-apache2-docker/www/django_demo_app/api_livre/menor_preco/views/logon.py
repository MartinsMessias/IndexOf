import requests


def logon():
    session = requests.Session()
    data = {
        'grant_type': 'password',
        'private_key': 'dyH2eQUJTdc:APA91bGvvTgLPAGiUfROzK6Dt_zOxPyS9xlUorK36SsLcYk_urHLOYc4fnJqVmwhIfTT8DSuvBbG0fcQ8E7uNWVIDa0gDvqnJg41sWSjITwH_o9ORLeOUNLvHoQMr19t3nJigWqyD4Ds'
    }
    response = session.post('https://mprs.sefaz.rs.gov.br/API/ConsultaMenorPrecoBrasil/logon', data=data)

    if response.status_code == 200:
        dados_logon = response.json()
        dados_token = dados_logon['token_type'] + " " + dados_logon['access_token']
        print('200')
    else:
        print('Ocorreu um erro na requisição de logon. ->', response)
        exit()
    return dados_token, session


dados_token, session = logon()
