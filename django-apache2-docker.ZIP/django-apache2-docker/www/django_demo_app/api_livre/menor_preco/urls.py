from django.urls import path
from .views import combustivel_view
from .views import produto_view

urlpatterns = [
    path('lista_combustivel/<str:lat>/<str:long>/<str:distancia>/<str:grupo>/<str:dias>', combustivel_view.combustivel_list, name='combustivel_list'),
    path('pesquisa_produto_nome/<str:produto>/<str:latitude>/<str:longitude>/<str:distancia>/<str:dias>', produto_view.pesquisa_produto, name='pesquisa_produto'),
    path('pesquisa_produto_gtin/<str:gtin>/<str:latitude>/<str:longitude>/<str:distancia>/<str:dias>', produto_view.pesquisa_produto_gtin, name='pesquisa_produto_gtin'),
    path('historico_produto/<str:codproduto>/<str:latitude>/<str:longitude>/<str:distancia>', produto_view.historico_produto, name='historico_produto'),
    path('', produto_view.index),
    
]
