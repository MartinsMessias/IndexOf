from django.apps import AppConfig


class MenorPrecoConfig(AppConfig):
    name = 'menor_preco'
