from django.http import HttpResponse
from ..services import produto_services
from django.shortcuts import render


def historico_produto(request, codproduto, latitude, longitude, distancia):
    items = produto_services.historico_produto(codproduto=codproduto, latitude=latitude, longitude=longitude,
                                               distancia=distancia)
    return HttpResponse(items, content_type='application/json')


def pesquisa_produto(request, produto, latitude, longitude, distancia, dias):
    items = produto_services.pesquisa_produto(produto=produto, latitude=latitude, longitude=longitude,
                                              distancia=distancia, dias=dias)
    return HttpResponse(items, content_type='application/json')


def pesquisa_produto_gtin(request, gtin, latitude, longitude, distancia, dias):
    items = produto_services.pesquisa_produto_gtin(gtin=gtin, latitude=latitude, longitude=longitude, distancia=distancia, dias=dias)
    return HttpResponse(items, content_type='application/json')

def index(request):
    return render(request, 'index.html')
