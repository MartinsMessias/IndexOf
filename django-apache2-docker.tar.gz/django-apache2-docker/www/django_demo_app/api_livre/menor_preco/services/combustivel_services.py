from ..views.logon import dados_token, session

def listar_combustivel(latitude, longitude, distancia, grupo, dias):
    # dados_token, session = logon()

    headers = {
        'Host': 'mprs.sefaz.rs.gov.br',
        'Connection': 'keep-alive',
        'Accept': 'application/json',
        'Authorization': dados_token,
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; motorola one Build/QPKS30.54-22-7; wv) AppleWebKit/537.36 (KHTML, '
                      'like Gecko) Version/4.0 Chrome/83.0.4103.101 Mobile Safari/537.36',
        'Origin': 'http://localhost',
        'X-Requested-With': 'br.gov.rs.procergs.mpbr',
        'Sec-Fetch-Site': 'cross-site',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Referer': 'http://localhost/resultado/tabs/lista',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7'
    }

    response = session.get(
        f'https://mprs.sefaz.rs.gov.br/API/ConsultaMenorPrecoBrasil/api/v1/Item/PorCombustivel?pesquisa.latitude={latitude}&pesquisa.longitude={longitude}&pesquisa.nroKmDistancia={distancia}&pesquisa.codGrupoAnp={grupo}&pesquisa.nroDiaPrz={dias}&pesquisa.origem=android',headers=headers)

    return response

